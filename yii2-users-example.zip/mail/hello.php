<h3>Hello... We are happy to see you...</h3>
<img src="<?= $message->embed($imageFileName); ?>">