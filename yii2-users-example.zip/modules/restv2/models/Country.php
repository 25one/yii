<?php

namespace app\modules\restv2\models;

use yii\db\ActiveRecord;

class Country extends ActiveRecord
{

public $country_population;
public $name_and_population;

public function fields()
{
    return [
        'code',
        'name',
        'country_population' => 'population',
        'name_and_population' => function () {
            return $this->name . ' - ' . $this->population;
        },
    ];
}

}
