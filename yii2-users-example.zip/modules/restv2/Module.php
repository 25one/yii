<?php
namespace app\modules\restv2;

class Module extends \yii\base\Module
{
    public function init()
    {
        parent::init();

    }
}
