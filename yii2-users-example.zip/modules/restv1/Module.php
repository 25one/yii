<?php
namespace app\modules\restv1;

class Module extends \yii\base\Module
{
    public function init()
    {
        parent::init();

    }
}
