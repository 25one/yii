<?php

namespace app\modules\restv1\controllers;

use yii\rest\Controller;
use app\modules\restv1\models\Country;
use app\models\Mylogin;

class CountryController extends Controller //!...
{

    public function checkAccess($user)
    {
        if(Mylogin::findOne($user)) {
            return Mylogin::find()->where(['id' => $user])->asArray()->all()[0]['username'];
        }
     }

    public function actionIndex()
    {
        return Country::find()->all();
    }

    public function actionViewitem($code=null)
    {
      if($code) {
        return Country::findOne($code);
      }
      else {
        return "Error format of url-string...";
      }
    }

    public function actionDeleteitem($code=null, $user=null)
    {
      if($code && $user) {
        if($this->checkAccess($user)) {
            if(Country::findOne($code)->delete()) {
               return "Success of deleting...";
            }
            else {
               return "Error of deleting...";
            }
        }
        else {
            return "You can't delete this item...";
        }
      }
      else {
            return "Error format of url-string...";
      }
    }

}
