<?php

namespace app\commands;

use yii\console\Controller;
use app\models\Surprisenew;

class CmdsurpriseController extends Controller
{

    public function actionIndex()
    {
    }

    public function actionStatus($code_status)
    {

       $model = new Surprisenew;
       $row_db_result = (new \yii\db\Query())
       ->select(['[[name]]', '[[limit_for_all]]', '[[limit_for_one]]'])
       ->from('{{surprisenew}}')
       ->where('[[status]] = :status')
       ->addParams([':status' => $code_status])
       ->orderBy('[[name]]')
       ->all();
       foreach($row_db_result as $result) {
          print_r($result['name'].' - '.$result['limit_for_all'].' - '.$result['limit_for_one']."\n");
       }

    }

}

