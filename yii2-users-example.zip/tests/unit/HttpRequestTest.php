<?php
namespace tests\unit;

use app\models\Country;

class HttpRequestTest extends \Codeception\Test\Unit
{

    protected $tester;
    
    protected function _before()
    {
    }

    protected function _after()
    {
    }

    public function testCountryRestApi()
    {

       $model = new Country;

       $model->attributes = \Yii::$app->request->post('Country');
       expect_not($model->code);

    }

}