﻿//...!!!САМОСТОЯТЕЛЬНО "ВКРАПЛЕННЫЙ" В view js
$(document).ready(function(){
//$("body").css("background-color", "lightblue");
});