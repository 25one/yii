<?php
return [
    'Here will be a HEADER...' => 'Здесь будет ЗАГОЛОВОК...',
    'Here will be a FOOTER...' => 'Здесь будет ПОДВАЛ...',
    'Contact us' => 'Свяжитесь с нами', 
];
