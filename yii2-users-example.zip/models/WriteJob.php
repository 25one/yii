<?php

namespace app\models;

use yii\base\Object;

class WriteJob extends Object implements \yii\queue\Job
{

    public $text;
    public $file;

    public function execute($queue)
    {
        file_put_contents($this->file, $this->text);
    }

}

