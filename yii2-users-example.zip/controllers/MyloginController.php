<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Mylogin;
use app\models\ProductCategory;
use app\models\Surprisenew;
use app\models\SurprisenewSearch;
use app\models\Country;
use app\models\MailerForm;
use app\models\WriteJob;
use yii\data\ActiveDataProvider;
use app\components\MyHelper;

class MyloginController extends Controller
{

    public $layout = 'basemylogin';

    public function behaviors()
    {
        return [
            /*
            'cache_server' => [
                'class' => 'yii\filters\PageCache',
                'only' => ['index'],
                'duration' => 60,
                //'variations' => [
                //    \Yii::$app->language,
                //],
                'dependency' => [
                    'class' => 'yii\caching\DbDependency',
                    'sql' => 'SELECT COUNT(*) FROM mylogin',
                ],
            ],
            */

            /*
            'cache_client' => [
                'class' => 'yii\filters\HttpCache',
                'only' => ['index'],
                'lastModified' => function ($action, $params) {
                   $q = new \yii\db\Query();
                   return $q->from('mylogin')->count();
                },
            ],
            */

        ];
    }

    public function actionIndex()
    {

       $model=new Mylogin;
       $model_=new ProductCategory;

       if(\Yii::$app->request->get()['language']) {
           \Yii::$app->language = \Yii::$app->request->get()['language'];
       }
       else {
          \Yii::$app->language = 'en';
       }
       \Yii::$app->session->set('language', \Yii::$app->language);

       $helper = new MyHelper;

       return $this->render('index', ['model' => $model, 'model_' => $model_]);

    }

    public function actionMailer()
    {

        if(\Yii::$app->request->get()['language']) {
           \Yii::$app->language=\Yii::$app->request->get()['language'];
        }
        else {
           \Yii::$app->language=\Yii::$app->session->get('language');
         }
        \Yii::$app->session->set('language', \Yii::$app->language);

        $model = new MailerForm();

        if ($model->load(\Yii::$app->request->post()) && $model->sendEmail()) {
            \Yii::$app->session->setFlash('mailerFormSubmitted');
            return $this->refresh();
        }
          return $this->render('mailer', [
              'model' => $model,
          ]);
    }

    public function actionAjaxspecialvalidation($login=null, $pass=null, $category=null, $language=null)
    {

    $model=new Mylogin;

    if(!$model->Ajaxspecialvalidation($login, $pass)) {

    $session = Yii::$app->session;

    $session->set('language', $language);

    $row_db_result = (new \yii\db\Query())
        ->select(['[[mylogin.id]]', '[[mylogin.password]]', '[[mylogin.username]]', '[[mylogin.image]]'])
        ->from('{{mylogin}}')
        ->join('left join', '{{product_category}}', '[[product_category.id_user]]=[[mylogin.id]]')
        ->where('[[mylogin.username]]=:username
                 and [[product_category.id]]=:product_category')
        ->addParams([':username' => $login,
                      //':password' => $pass, //...��� ���� ��� hash password - �� �����...
                      ':product_category' => $category])
        ->all();

     if($row_db_result && Yii::$app->getSecurity()->validatePassword($pass, $row_db_result[0]['password'])) {
        $session->set('id_user', $row_db_result[0]['id']);
        $session->set('name_user', $row_db_result[0]['username']);
        $session->set('image_user', $row_db_result[0]['image']);

        return $this->redirect('login');

     }
     else {
        return 'Access error...';
     }

     }
     else {
        return $model->Ajaxspecialvalidation($name, $email);
     }

    }

    public function actionLogin()
    {

       $model_surprise=new Surprisenew;
       $model_country=new Country;
       $session = Yii::$app->session;

       if(\Yii::$app->request->get()['language']) {
          \Yii::$app->language=\Yii::$app->request->get()['language'];
       }
       else {
          \Yii::$app->language=$session->get('language');
       }
       \Yii::$app->session->set('language', \Yii::$app->language);


       //�������� ������� � �������
       /*
       $id = Yii::$app->queue->push(new WriteJob([   //...?��� ����������� - ������� ��� �������� ������� ������...
           'text' => 'test_new',
           'file' => Yii::$app->basePath . '/web/file.txt'
       ]));
       //...� ��� �� run-������� - ��������� Watcer-�� �� cron...   \
       //Yii::$app->queue->run();
       //...� ��� �� run-������� - ��������� Watcer-�� �� cron...
       */
       //...

       if($model_surprise->load(\Yii::$app->request->post())) {
          if ($model_surprise->validate()) {
             $model_surprise->name = Yii::$app->request->post('Surprisenew')['name'];
             $model_surprise->limit_for_all = Yii::$app->request->post('Surprisenew')['limit_for_all'];
             $model_surprise->limit_for_one = Yii::$app->request->post('Surprisenew')['limit_for_one'];
             $model_surprise->status = Yii::$app->request->post('Surprisenew')['status'];
             $model_surprise->id_user = $session->get('id_user');
             $model_surprise->insert();
          }
       }

       if($session->get('id_user')==1) {

           $searchModel_surprise = new SurprisenewSearch();
           $provider_surprise = $searchModel_surprise->search(Yii::$app->request->get());

           $provider_surprise->pagination->pageParam = 'surprise-page';
           $provider_surprise->sort->sortParam = 'surprise-sort';


       }


       $provider_country = new ActiveDataProvider([
            'query' => $model_country->find(),
            'pagination' => [
                'pageSize' => 10,
            ],
            'sort' => [
                'defaultOrder' => [
                    'name' => SORT_ASC,
                ],
             ],
       ]);

       $provider_country->pagination->pageParam = 'country-page';
       $provider_country->sort->sortParam = 'country-sort';

       return $this->render('login', ['model_surprise' => $model_surprise, 'provider_surprise' => $provider_surprise, 'searchModel_surprise' => $searchModel_surprise, 'provider_country' => $provider_country]);

    }

    public function actionSurprisenewLeadDelete($id)
    {

       $model=new Surprisenew;

       $model->findOne($id)->delete();

       return $this->redirect('/login');

    }

    public function actionSurprisenewLeadUpdateSelect($model_name, $id)
    {

       $model=new Surprisenew;
       $row_db_result = $model->find()->where(['id' => $id])
                              ->asArray()->all();
       return json_encode($row_db_result);

    }

    public function actionSurprisenewLeadUpdateSave($id, $name, $limit_for_all, $limit_for_one, $status)
    {

       $model=new Surprisenew;

       if(!$model->Ajaxspecialvalidation($name, $limit_for_all, $limit_for_one, $status)) {
            $updating = $model->findOne($id);
            $updating->name = $name;
            $updating->limit_for_all = $limit_for_all;
            $updating->limit_for_one = $limit_for_one;
            $updating->status = $status;
            $updating->update();

       }
       else {
          return $model->Ajaxspecialvalidation($name, $limit_for_all, $limit_for_one, $status);
       }

    }

}
