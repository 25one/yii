﻿var BaseRecord=(function() {
$(document).ready(function() {
     $("body").on("click", ".button_login", function(){BaseRecord.validate($(".text_login").val(), $(".text_password").val());});
     $("body").on("keypress", ".text_login", function(){if(event.which==13) {BaseRecord.validate($(".text_login").val(), $(".text_password").val());}});
     $("body").on("keypress", ".text_password", function(){if(event.which==13) {BaseRecord.validate($(".text_login").val(), $(".text_password").val());}});
     $("body").on("click", ".button_add_task", function(){$("[name='form_new_task']").attr("method", "post"); $(this).attr("type", "submit");}); //!!!...С ПЕРЕГРУЗКОЙ...
     $("body").on("click", "[name='button_delete_task']", function(){BaseRecord.deletetask($(this).attr("value"));});
});
return {

   validate:function(login, password) {
      var r=/^[\w\d_]+$/i;
      if(!r.test(login) || password=="") {
         $(".span_error").html("Bad format of login or password!");
      }
      else {
         $(".span_error").html("");
         $(".button_login").attr("type", "submit");
      }
   },

   deletetask:function(id_task) {
      var ajaxSetting={
          method:"post",
          url:"?r=listtask/ajaxdelete",
          data:"delete_task="+id_task,
          success: function(data) {
           var data_json=JSON.parse(data);
           var string_json="";
           for(var i in data_json) {
              string_json+='<div class="row_td"><div class="cell_td" style="width:30%;">'+data_json[i]['name_task']+'</div>';
              string_json+='<div class="cell_td cell_td_center" style="width:60%;">'+data_json[i]['content_task']+'</div>';
              string_json+='<div class="cell_td cell_td_center" style="width:10%;"><button type="button" name="button_delete_task" value="'+data_json[i]['id']+'">Delete</button></div></div>';
           }
           $(".table_all_task_content").html(string_json);
          },
      };
      $.ajax(ajaxSetting);
   },

};

})();
