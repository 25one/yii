<?php

class ListtaskController extends Controller
{

	public function actionIndex()
	{


      $model = new Listtask;

      if (Yii::app()->request->getPost('Listtask')) {
         $model->attributes = Yii::app()->request->getPost('Listtask');
         if($model->validate()) {
            $results_insert=$model->make_insert('tasks', array('id_user'=>Yii::app()->session['id_user'], 'name_task'=>$model->attributes['name_task'], 'content_task'=>$model->attributes['content_task']));
         }
         else {
           $errors = $model->errors;
         }
      }

      $sql='select `tasks`.`id`, `tasks`.`name_task`, `tasks`.`content_task` from `tasks` where `tasks`.`id_user`='.Yii::app()->session['id_user'];
      $results=$model->make_select($sql);
      $this->renderPartial('index', array('model'=>$model, 'results'=>$results, 'results_insert'=>$results_insert, 'errors_validate'=>$errors));

	}

	public function actionAjaxdelete()
	{

      $model = new Listtask;

      $model->make_delete('tasks', 'id=:id', array(':id'=>$_POST['delete_task']));

      $sql='select `tasks`.`id`, `tasks`.`name_task`, `tasks`.`content_task` from `tasks` where `tasks`.`id_user`='.Yii::app()->session['id_user'];
      $results=$model->make_select($sql);

      echo json_encode($results);

    }

}
