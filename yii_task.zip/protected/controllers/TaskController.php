<?php

class TaskController extends Controller
{

	public function actionLogin()
	{

      $model = new Task;

      if (Yii::app()->request->getPost('Task')) {
	    $model->attributes = Yii::app()->request->getPost('Task');
        if($model->validate()) {
           $sql='select `tasks_users`.`id` from `tasks_users` where `tasks_users`.`login`="'.$model->attributes['login'].'" and `tasks_users`.`password`="'.$model->attributes['password'].'"';
           $results=$model->make_select($sql);
           if($results[0]['id']) {
              Yii::app()->session['id_user']=$results[0]['id'];
              $this->redirect(array('listtask/index'));
           }
           else {
              $this->renderPartial('login', array('model'=>$model, 'errors_autentificate'=>'Mistake in login or password!'));
           }
        }
        else {
           $errors = $model->errors;
           $this->renderPartial('login', array('model'=>$model, 'errors_validate'=>$errors));
       }

      }
      else {
         $this->renderPartial('login', array('model'=>$model));  
      }

	}

}
