<!DOCTYPE html>
<html lang="en">
<head>
<title>Task-Login</title>
<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<link rel="stylesheet" type="text/css" href="<? echo Yii::app()->request->getBaseUrl(true); ?>/css/mine_task.css">
<link rel="stylesheet" type="text/css" href="<? echo Yii::app()->request->getBaseUrl(true); ?>/css/app.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="<? echo Yii::app()->request->getBaseUrl(true); ?>/js/mine_task.js"></script>
</head>
<body>

<div class="container">

<div class="people_login">

<div class="table">
<?php $form = $this->beginWidget('CActiveForm'); ?>
<div class="row_td">
    <div class="cell_td cell_td_mobile">
    <?php echo $form->label($model,'login'); ?>
    </div>
    <div class="cell_td cell_td_mobile">
    <?php echo $form->textField($model,'login',array('class'=>'text_login','value'=>'alex')); ?> <span class="title_login">(only a-z,A-Z,0-9,_)</span>
    </div>
</div>
<div class="row_td">
    <div class="cell_td cell_td_mobile">
    <?php echo $form->label($model,'password'); ?>
    </div>
    <div class="cell_td cell_td_mobile">
    <?php echo $form->passwordField($model,'password',array('class'=>'text_password','value'=>'12345678')); ?> <span class="title_login">(required)</span>
    </div>
</div>
<div class="row_td">
    <div class="cell_td cell_td_mobile">
    <?php echo CHtml::button('Login', array('class'=>'button_login')); ?>
    </div>
    <div class="cell_td cell_td_mobile">
    <?php if($errors_validate) { ?>
    <span class="span_error">Bad format of login or password!</span>
    <?php } else if($errors_autentificate) { ?>
    <span class="span_error"><?php echo $errors_autentificate; ?></span>
    <?php } else { ?>
    <span class="span_error"></span>
    <?php } ?>
    </div>
</div>
<?php $this->endWidget(); ?>
</div>

</div>

</div>

</body>
</html>