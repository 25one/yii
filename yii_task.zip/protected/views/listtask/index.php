<!DOCTYPE html>
<html lang="en">
<head>
<title>Task-List</title>
<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<link rel="stylesheet" type="text/css" href="<? echo Yii::app()->request->getBaseUrl(true); ?>/css/mine_task.css">
<link rel="stylesheet" type="text/css" href="<? echo Yii::app()->request->getBaseUrl(true); ?>/css/app.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="<? echo Yii::app()->request->getBaseUrl(true); ?>/js/mine_task.js"></script>
</head>
<body>

<div class="container">

<?php echo CHtml::beginForm(); ?>
<div class="new_task">

    <div class="table_new_task">
      <div class="row_td">
      <div class="cell_td cell_td_mobile">
      Name of new task
      </div>
      <div class="cell_td">
      <?php echo CHtml::activeTextField($model,'name_task',array('class'=>'name_task', 'value'=>'', 'placeholder'=>'write name of new task')); ?> <span class="title_login">(required)</span>
      </div>
      </div>

      <div class="row_td">
      <div class="cell_td cell_td_mobile">
      Content of new task
      </div>
      <div class="cell_td">
      <?php echo CHtml::activeTextField($model,'content_task',array('class'=>'content_task', 'value'=>'', 'placeholder'=>'write content of new task')); ?> <span class="title_login">(required)</span>
      </div>
      </div>

      <div class="row_td">
      <div class="cell_td">
      <?php echo CHtml::button('Add',array('class'=>'button_add_task')); ?>
      </div>
      <div class="cell_td">
        <?php if($errors_validate) { ?>
        <span class="span_error">Bad format of name or content of task!</span>
        <?php } else { ?>
        <span class="span_error"></span>
        <?php } ?>
      </div>
      </div>
    </div>
</div>
<?php echo CHtml::endForm(); ?>

<hr>

<div class="all_task">
<div class="table_all_task_title">
<div class="row_td">
      <div class="cell_td cell_th" style="width:30%;">
      Name of task
      </div>
      <div class="cell_td cell_th" style="width:60%;">
      Content of task
      </div>
      <div class="cell_td cell_th" style="width:10%;">
      Delete
      </div>
</div>
</div>
<div class="table_all_task_content">
<?php
if(isset($results)) {
foreach($results as $k1=>$results1) {
?>
<div class="row_td">
      <div class="cell_td" style="width:30%;">
      <?php echo($results1['name_task']); ?>
      </div>
      <div class="cell_td" style="width:60%;">
      <?php echo($results1['content_task']); ?>
      </div>
      <div class="cell_td cell_td_center" style="width:10%;">
      <button type="button" name="button_delete_task" value="<?php echo($results1['id']); ?>">Delete</button>
      </div>
</div>
<?php
}
}
?>
</div>
</div>

</div>

</body>
</html>