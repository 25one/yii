<?php

class Task extends CFormModel

{

    public $login;
    public $password;

	public function rules()
	{
		return array(
            array('login', 'validateLogin'),      //!!!ВСТРОЕННЫЙ ВАЛИДАТОР(НИЖЕ)...
            array('password', 'required', 'message' => ' - required for fuling'),

		);
	}

	public function validateLogin($attribute)
	{
		if(!$this->hasErrors())
		{
          if (!preg_match('/^[\w\d_]+$/iu', $this->$attribute)) {
             $this->addError($attribute, ' - only a-z,A-Z,0-9,_');
          }
		}
	}

	public function make_select($sql)
	{
       return Yii::app()->db->createCommand($sql)->queryAll();
	}

}
