<?php

class Listtask extends CFormModel

{

    public $name_task;
    public $content_task;

	public function rules()
	{
		return array(
		    array('name_task, content_task', 'required', 'message' => 'required field for fuling'),
		);
	}

	public function make_select($sql)
	{
       return Yii::app()->db->createCommand($sql)->queryAll();
	}

	public function make_insert($table, $array_insert)
	{
       $command = Yii::app()->db->createCommand();
       $command->insert($table, $array_insert);
	}

	public function make_delete($table, $string_delete, $array_delete)
	{
       $command = Yii::app()->db->createCommand();
       $command->delete($table, $string_delete, $array_delete);
	}

}
